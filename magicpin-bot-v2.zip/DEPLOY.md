# Deploy on Render (free), about 10 minutes

## A. Generate submission.jsonl locally (needs your key)
1. `pip install -r requirements.txt`
2. PowerShell: `$env:ANTHROPIC_API_KEY="sk-ant-..."`
3. `python make_submission.py` writes 30 lines to `submission.jsonl`. Check that the lines don't say "Template fallback" in the rationale. If they do, the key didn't work.

## B. Push the code to GitHub
4. On github.com, click **New repository**. Give it any name, make it **Private**, and don't add a README.
5. In this folder:
   ```
   git init
   git add .
   git commit -m "Vera simple bot"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```

## C. Create the Render service
6. Go to https://render.com, click **Get Started**, and sign in with GitHub.
7. Click **New +** (top right), then **Web Service**.
8. **Connect** your repo. If it isn't listed, click "Configure account" and give Render access to it.
9. Fill in the form:
   - **Name:** anything (it becomes `https://<name>.onrender.com`)
   - **Language/Runtime:** Python 3
   - **Branch:** main
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn bot:app --host 0.0.0.0 --port $PORT --workers 1`
   - **Instance Type:** Free
10. Scroll to **Environment Variables** and click **Add Environment Variable** for each of these:
    - `ANTHROPIC_API_KEY` = `sk-ant-...` ← **your key goes here**
    - `PYTHON_VERSION` = `3.12.7`
    - `TEAM_NAME` = your team name
    - `TEAM_MEMBERS` = `Your Name` (for several people, separate with commas)
    - `CONTACT_EMAIL` = your college email
11. (Optional) Open **Advanced** and set **Health Check Path** to `/v1/healthz`.
12. Click **Create Web Service** and wait for the logs to show "Your service is live" (about 2-4 min).

## D. Check it
13. Open `https://<name>.onrender.com/v1/healthz` in a browser. It should return `{"status":"ok",...}`.
14. From this folder, run `python smoke_test.py https://<name>.onrender.com`. It should end with `ALL PASS`, and the tick messages should read like real Vera messages, not "a quick ... update".
15. Submit `https://<name>.onrender.com` on the challenge portal.

## Gotchas
- **Free Render sleeps after 15 min idle.** The first request after that takes about 50 s, which is longer than the judge's 30 s timeout. Keep it awake during the test window: add a free monitor on https://uptimerobot.com that sends an HTTP GET to `/v1/healthz` every 5 min.
- **Don't push or redeploy during the test.** A restart wipes the in-memory contexts.
- If you'd rather use Docker, the `Dockerfile` works too. In step 9, pick **Docker** as the runtime and leave the build and start commands empty.
