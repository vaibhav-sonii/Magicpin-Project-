"""Quick end-to-end check of all endpoints.  python smoke_test.py [BOT_URL]"""
import json
import sys
import urllib.request
from pathlib import Path

URL = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8080").rstrip("/")
DATA = Path(__file__).parent / "dataset"


def call(path, body=None):
    req = urllib.request.Request(URL + path, method="POST" if body is not None else "GET",
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def push(scope, cid, payload, version=1):
    return call("/v1/context", {"scope": scope, "context_id": cid, "version": version,
                                "payload": payload, "delivered_at": "2026-04-26T10:00:00Z"})


ok = True
def check(name, cond):
    global ok
    ok &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name)


check("healthz", call("/v1/healthz")[0] == 200)
check("metadata", "team_name" in call("/v1/metadata")[1])

for scope, folder in [("category", "categories"), ("merchant", "merchants"), ("customer", "customers")]:
    for f in (DATA / folder).glob("*.json"):
        push(scope, f.stem, json.loads(f.read_text(encoding="utf-8")))
counts = call("/v1/healthz")[1]["contexts_loaded"]
check(f"base dataset loaded {counts}", counts["category"] == 5 and counts["merchant"] == 50 and counts["customer"] == 200)

m = json.loads((DATA / "merchants/m_001_drmeera_dentist_delhi.json").read_text(encoding="utf-8"))
check("same version = no-op 200", push("merchant", "m_001_drmeera_dentist_delhi", m, 1)[0] == 200)
check("newer version accepted", push("merchant", "m_001_drmeera_dentist_delhi", m, 2)[0] == 200)
check("stale version -> 409", push("merchant", "m_001_drmeera_dentist_delhi", m, 1)[0] == 409)
check("bad scope -> 400", push("banana", "x", {})[0] == 400)

trg_ids = ["trg_001_research_digest_dentists", "trg_003_recall_due_priya"]
for t in trg_ids:
    push("trigger", t, json.loads((DATA / f"triggers/{t}.json").read_text(encoding="utf-8")))
actions = call("/v1/tick", {"now": "2026-04-26T10:30:00Z", "available_triggers": trg_ids})[1]["actions"]
check(f"tick returned {len(actions)} actions", len(actions) == 2)
for a in actions:
    print("   ", a["send_as"], "|", a["body"])
check("tick again -> no duplicate sends", call("/v1/tick", {"now": "x", "available_triggers": trg_ids})[1]["actions"] == [])

conv = actions[0]["conversation_id"]
def rep(msg, n):
    return call("/v1/reply", {"conversation_id": conv, "merchant_id": "m_001_drmeera_dentist_delhi",
                              "from_role": "merchant", "message": msg, "received_at": "x", "turn_number": n})[1]
r = rep("Yes please, go ahead", 2); print("   ", r); check("intent -> send", r["action"] == "send" and r["body"])
auto = "Thank you for contacting us! We will get back to you shortly."
r = rep(auto, 3); print("   ", r); check("auto-reply -> one nudge", r["action"] == "send")
r = rep(auto, 4); print("   ", r); check("auto-reply again -> end", r["action"] == "end")

r = call("/v1/reply", {"conversation_id": "conv_new", "merchant_id": "m_001_drmeera_dentist_delhi",
                       "from_role": "merchant", "message": "not interested, stop", "received_at": "x", "turn_number": 2})[1]
check("opt-out -> end", r["action"] == "end")

print("\nALL PASS" if ok else "\nSOME CHECKS FAILED")
