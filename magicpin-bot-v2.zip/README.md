# Vera (simple): magicpin AI Challenge submission

## Approach
Everything is in **one file, `bot.py`**, and composing uses **one LLM prompt**.

1. **Prompt.** `compose(category, merchant, trigger, customer)` sends the four contexts to Claude (`claude-sonnet-4-6`, temperature 0) as JSON. It sends only the category fields that matter plus the digest item the trigger points at. A short rulebook comes with it: say *why now* first, use at least one real number/price/source, never invent data, follow the category's voice and taboos, use Hinglish when the merchant speaks Hindi, and end with exactly one CTA. The LLM returns `{body, cta, rationale}`. The code fills in `send_as` (a customer is present means `merchant_on_behalf`) and `suppression_key`.
2. **Post-checks.** Three cheap checks: the body isn't empty, it has at most one CTA, and it doesn't repeat an earlier message word for word. If a check fails, we re-prompt once and tell the model why. If the LLM is down, a plain template sends a safe message instead, so no endpoint ever errors.
3. **Replies (`/v1/reply`).** Small rules come first:
   - opt-out words lead to `end`
   - an auto-reply (a known phrase, or the same text repeated) gets one nudge, then `end`
   - "busy/later" leads to `wait` 30 min

   Everything else goes to a second short prompt: act on a yes, answer questions honestly, stay polite and on-mission for off-topic or rude messages, and match their language.
4. **Server.** FastAPI with the 5 required endpoints, adapted from the official skeleton. State lives in memory: contexts are versioned by `(scope, id)`, conversations are kept by id, and suppression keys stop duplicate sends. `/v1/tick` composes up to 8 triggers in parallel, well inside the 30 s budget.

## Tradeoffs
- **One prompt instead of one per trigger kind.** It's easier to explain and maintain. The cost is that some trigger kinds (for example, a perf dip versus a research digest) get less tailored framing.
- **Raw JSON in the prompt instead of pre-computed facts.** Simple, but the model has to find the right number itself, and it sometimes picks a less compelling one.
- **Regex rules for replies.** Fast and predictable, but they can miss unusual auto-replies or opt-outs worded in other ways.
- **In-memory state.** Allowed by the brief. A restart loses everything, so the server runs as a single worker.

## What would improve it with more time
- Prompt variants per trigger family, plus a small "fact picker" that ranks the strongest number for each merchant.
- An LLM-based check for language match and taboo words, not just the CTA/repeat checks.
- Using the WhatsApp 24h-window rules properly (template-only first message) and planning the cadence across ticks.
- Redis/SQLite so state survives restarts.
- Scoring outputs with the provided `judge_simulator.py` and tuning the prompt on the weakest dimension.

## Files
`bot.py` (compose + validation + API) · `make_submission.py` (30 test pairs → `submission.jsonl`) · `smoke_test.py` (endpoint checks) · `dataset/` (generated with the kit's fixed-seed generator) · `requirements.txt`, `Dockerfile`, `render.yaml`
