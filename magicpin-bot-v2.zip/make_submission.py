"""
Loop over the official 30 test pairs and write submission.jsonl.

    set ANTHROPIC_API_KEY=sk-ant-...     (PowerShell: $env:ANTHROPIC_API_KEY="sk-ant-...")
    python make_submission.py

dataset/ is created by the kit's own generator (fixed seed, same for everyone):
    python _kit/dataset/generate_dataset.py --seed-dir _kit/dataset --out dataset
"""
import json
from pathlib import Path

from bot import compose

DATA = Path(__file__).parent / "dataset"


def load(folder: str, item_id: str | None) -> dict | None:
    if not item_id:
        return None
    path = DATA / folder / f"{item_id}.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def main():
    pairs = json.loads((DATA / "test_pairs.json").read_text(encoding="utf-8"))["pairs"]
    with open("submission.jsonl", "w", encoding="utf-8") as out:
        for p in pairs:
            trigger = load("triggers", p["trigger_id"])
            merchant = load("merchants", p["merchant_id"])
            category = load("categories", merchant["category_slug"])
            customer = load("customers", p.get("customer_id"))
            msg = compose(category, merchant, trigger, customer)
            out.write(json.dumps({"test_id": p["test_id"], **msg}, ensure_ascii=False) + "\n")
            print(p["test_id"], "|", msg["body"][:90].replace("\n", " "))
    print(f"\nWrote {len(pairs)} lines to submission.jsonl")


if __name__ == "__main__":
    main()
